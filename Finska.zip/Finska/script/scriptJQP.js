$(function () {
    $(".jqui").accordion({
        collapsible: true
    });
});
